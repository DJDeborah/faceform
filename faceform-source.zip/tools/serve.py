"""Static development server. No upload or reconstruction endpoint is exposed."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT/'dist')
class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control','no-cache')
        super().end_headers()
    def guess_type(self,path):
        if path.endswith('.js') or path.endswith('.mjs'): return 'text/javascript'
        return super().guess_type(path)
print('Local: http://127.0.0.1:8765',flush=True)
ThreadingHTTPServer(('127.0.0.1',8765),Handler).serve_forever()
