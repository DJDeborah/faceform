import fs from 'node:fs';
import path from 'node:path';
import {castingMolds} from '../dist/js/molds.js';
import {binarySTL} from '../dist/js/geometry.js';

const [source,destination,...options]=process.argv.slice(2);
if(!source||!destination)throw Error('Usage: node tools/export-molds.mjs face.stl output-folder [--shell] [--resolution=0.6] [--thickness=4]');
const bytes=fs.readFileSync(source),view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),count=bytes.length>=84?view.getUint32(80,true):0;
let positions=[];
if(count&&84+count*50===bytes.length){positions=new Float32Array(count*9);for(let i=0;i<count;i++)for(let k=0;k<9;k++)positions[i*9+k]=view.getFloat32(84+i*50+12+k*4,true);}
else{const text=bytes.toString('utf8');for(const match of text.matchAll(/\bvertex\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)/g))positions.push(Number(match[1]),Number(match[2]),Number(match[3]));positions=new Float32Array(positions);}
if(!positions.length||positions.length%9||positions.some(x=>!Number.isFinite(x)))throw Error('STL does not contain valid triangles');
const numberOption=(name,fallback)=>{const value=options.find(x=>x.startsWith('--'+name+'='));return value?Number(value.split('=')[1]):fallback;};
const faces=Uint32Array.from({length:positions.length/3},(_,i)=>i),molds=castingMolds(positions,faces,{sourceShell:options.includes('--shell'),moldResolution:numberOption('resolution',.6),thickness:numberOption('thickness',4)},(text,p)=>console.log(Math.round(p)+'% '+text));
fs.mkdirSync(destination,{recursive:true});
for(const name of ['female','male']){const part=molds[name];fs.writeFileSync(path.join(destination,name+'_casting_mold_mm.stl'),new Uint8Array(binarySTL(part.vertices,part.faces)));}
molds.report.sourceFile=path.basename(source);molds.report.sourceUnits='STL numeric scale interpreted as millimetres; no automatic scaling';
fs.writeFileSync(path.join(destination,'mold_report.json'),JSON.stringify(molds.report,null,2));
console.log(JSON.stringify({sourceSizeMm:molds.report.sourceSizeMm,maleSizeMm:molds.report.male.sizeMm,femaleSizeMm:molds.report.female.sizeMm,surfaceFilterMaxDeviationMm:molds.report.surfaceFilterMaxDeviationMm}));
